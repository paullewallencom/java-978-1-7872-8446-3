public class Song {
    String name;

}
