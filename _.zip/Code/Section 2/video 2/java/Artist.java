public class Artist {
    String name;
    Album album;
}
