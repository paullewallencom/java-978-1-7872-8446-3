public class Listener {
    String name;
    Song listenedToSong;
}
