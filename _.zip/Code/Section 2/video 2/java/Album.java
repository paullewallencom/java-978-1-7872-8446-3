public class Album {
    String albumName;
    Song firstSong;
}
