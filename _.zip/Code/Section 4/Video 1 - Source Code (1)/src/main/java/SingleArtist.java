public class SingleArtist extends AbstractArtist {
    public static final String ARTIST_TYPE = "Single Artist";

    public SingleArtist(String name) {
        super(name);
    }
}
